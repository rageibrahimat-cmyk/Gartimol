"""
Pydantic models for the TrustScoring bounded context.

Per §2 of the architecture spec, this context owns score computation,
score history, and the explainability breakdown. It does not own
PlanGoal or ActivityEvent data — those are read-only inputs from
upstream contexts.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class PlanGoal(BaseModel):
    """Read-only projection of a goal owned by the SeasonalContext/PlanGoal context."""

    category: str
    target_value: float = Field(gt=0)


class ActivityEvent(BaseModel):
    """Read-only projection of an event owned by the Ledger/Alerting context."""

    category: str
    value: float
    occurred_at: datetime


class Alert(BaseModel):
    """Read-only projection of an alert owned by the Alerting context."""

    status: str  # e.g. "actioned", "pending", "dismissed"
    created_at: datetime


class TrustScoreBreakdown(BaseModel):
    plan_adherence: Optional[float] = None
    action_completion: Optional[float] = None


class TrustScoreResponse(BaseModel):
    score: float
    computed_at: datetime
    breakdown: TrustScoreBreakdown
    explanation: str


class InsufficientDataResponse(BaseModel):
    status: str = "insufficient_data"
    next_step: str = "declare_plan_goals"


class HistoryPoint(BaseModel):
    score: float
    computed_at: datetime


class RecomputeQueuedResponse(BaseModel):
    status: str = "queued"


class TrustScoreSnapshot(BaseModel):
    """Mirrors the `trust_score_snapshot` table owned by this context (§2)."""

    id: UUID
    user_id: UUID
    score: float = Field(ge=0, le=100)
    plan_adherence: Optional[float] = None
    action_completion: Optional[float] = None
    computed_at: datetime
    inputs_snapshot: dict
