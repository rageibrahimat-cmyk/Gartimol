"""
Trust Score computation logic — implements §3 of the architecture spec.

    Trust Score = (0.6 x Plan Adherence) + (0.4 x Action Completion Rate)

This module is pure computation with no I/O, so it can be unit tested
in isolation from the DB/API layer. Per the handoff notes (§8), the
null-handling cases here are the ones most likely to be silently wrong
in a way that damages user trust, so they're implemented explicitly
and tested first.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional

from app.schemas import ActivityEvent, Alert, PlanGoal

PLAN_ADHERENCE_WEIGHT = 0.6
ACTION_COMPLETION_WEIGHT = 0.4
ACTION_COMPLETION_WINDOW_DAYS = 7


@dataclass
class ScoreResult:
    score: Optional[float]
    plan_adherence: Optional[float]
    action_completion: Optional[float]
    explanation: str
    insufficient_data: bool = False


def compute_plan_adherence(
    goals: Iterable[PlanGoal],
    events: Iterable[ActivityEvent],
    period_start: datetime,
    period_end: datetime,
) -> Optional[float]:
    """
    §3.1 Plan Adherence (0-100).

    For each declared goal, adherence_pct = MIN(actual / target, 1.0) * 100,
    averaged across all active goals.

    Edge case: zero declared goals -> None (excluded from score, not a 0).
    """
    goals = list(goals)
    if not goals:
        return None

    events = list(events)
    adherence_pcts = []
    for goal in goals:
        actual = sum(
            e.value
            for e in events
            if e.category == goal.category and period_start <= e.occurred_at <= period_end
        )
        # target_value is validated > 0 at the schema level, so no div-by-zero guard needed.
        adherence_pct = min(actual / goal.target_value, 1.0) * 100
        adherence_pcts.append(adherence_pct)

    return sum(adherence_pcts) / len(adherence_pcts)


def compute_action_completion(
    alerts: Iterable[Alert],
    now: datetime,
    window_days: int = ACTION_COMPLETION_WINDOW_DAYS,
) -> Optional[float]:
    """
    §3.2 Action Completion Rate (0-100).

    completed / total over the last `window_days`.

    Edge case: zero alerts in window -> None (excluded, not a 0 and not
    treated as 100%).
    """
    window_start = now - timedelta(days=window_days)
    windowed = [a for a in alerts if window_start <= a.created_at <= now]

    total = len(windowed)
    if total == 0:
        return None

    completed = sum(1 for a in windowed if a.status == "actioned")
    return (completed / total) * 100


def _explain(plan_adherence: Optional[float], action_completion: Optional[float]) -> str:
    if plan_adherence is not None and action_completion is not None:
        return (
            f"{plan_adherence:.1f}% adherence to your declared plan categories, "
            f"{action_completion:.1f}% of recommended actions completed in the last "
            f"{ACTION_COMPLETION_WINDOW_DAYS} days."
        )
    if plan_adherence is not None:
        return (
            f"{plan_adherence:.1f}% adherence to your declared plan categories. "
            "No alerts in the last 7 days, so action completion isn't factored in yet."
        )
    if action_completion is not None:
        return (
            f"{action_completion:.1f}% of recommended actions completed in the last "
            f"{ACTION_COMPLETION_WINDOW_DAYS} days. No declared plan goals yet, so plan "
            "adherence isn't factored in."
        )
    return "Not enough data yet to compute a Trust Score."


def compute_trust_score(
    goals: Iterable[PlanGoal],
    events: Iterable[ActivityEvent],
    alerts: Iterable[Alert],
    now: Optional[datetime] = None,
    period_start: Optional[datetime] = None,
    period_end: Optional[datetime] = None,
) -> ScoreResult:
    """
    §3.3 Final score.

        both present   -> 0.6 * plan_adherence + 0.4 * action_completion
        only adherence  -> plan_adherence
        only completion -> action_completion
        neither         -> None ("not enough data yet", never fake a number)
    """
    now = now or datetime.now(timezone.utc)
    period_end = period_end or now
    period_start = period_start or (period_end - timedelta(days=30))

    plan_adherence = compute_plan_adherence(goals, events, period_start, period_end)
    action_completion = compute_action_completion(alerts, now)

    if plan_adherence is not None and action_completion is not None:
        score = PLAN_ADHERENCE_WEIGHT * plan_adherence + ACTION_COMPLETION_WEIGHT * action_completion
    elif plan_adherence is not None:
        score = plan_adherence
    elif action_completion is not None:
        score = action_completion
    else:
        score = None

    return ScoreResult(
        score=score,
        plan_adherence=plan_adherence,
        action_completion=action_completion,
        explanation=_explain(plan_adherence, action_completion),
        insufficient_data=score is None,
    )
